from werkzeug.utils import secure_filename
from flask_session import *
from flask import Flask, session,render_template, jsonify, request,redirect,escape,url_for
import os
from user import *
import json
import time
import redis
re = redis.Redis(host='192.168.43.68', port=6379)

from flask_cors import *
import base64

# rsa算法生成实例
app = Flask(__name__)

UPLOAD_FOLDER = 'static'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
basedir = os.path.abspath(os.path.dirname(__file__))
ALLOWED_EXTENSIONS = set(['txt', 'png', 'jpg', 'xls', 'JPG', 'PNG', 'xlsx', 'gif', 'GIF'])





def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS
CORS(app, supports_credentials=True)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'


@app.route('/add_goods',methods=['GET','POST'])
def add_goods():
    if request.method=="GET":
        return  render_template('add_goods.html')
    else:
        file_dir = os.path.join(basedir, app.config['UPLOAD_FOLDER'])
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        f = request.files['myfile']  # 从表单的file字段获取文件，myfile为该表单的name值
        goods_name = request.form['goods_name']
        goods_nums = int(request.form['goods_nums'])
        goods_price = int(request.form['goods_price'])
        goods_type = request.form['goods_type']
        pic_list = []
        pic_num = int(request.form['length'])
        for l in range(0,pic_num):
            pic_list.append(request.files[str(l)])
        
        #main_pic_addr = request.form['myfile'].filename
        try:
            if f and allowed_file(f.filename):  # 判断是否是允许上传的文件类型
                fname = secure_filename(f.filename)
                ext = fname.rsplit('.', 1)[1]  # 获取文件后缀
                unix_time = int(time.time())
                new_filename = str(unix_time) + '.' + ext  # 修改了上传的文件名
                f.save(os.path.join(file_dir, new_filename))  # 保存文件到upload目录
                goods = Goods(goods_name, goods_nums, goods_price, goods_type, new_filename)
                flag = goods.add_sql()
                print(flag)
                if flag==0:
                    return jsonify({'mess': 'error'})
                else:
                    print((pic_list[0].filename))
                    try:
                        
                        for l in pic_list:
                            
                            fname = secure_filename(l.filename)
                            ext = fname.rsplit('.', 1)[1]  # 获取文件后缀
                            unix_time = int(time.time()*100000)
                            new_filename = str(unix_time) + '.' + ext  # 修改了上传的文件名
                            l.save(os.path.join(file_dir, new_filename))  # 保存文件到upload目录
                            op_sql(f"insert into pics(goods_id,pic_addr) v"
                                   f"alue ('{flag}','{new_filename}')")
                        return jsonify({'mess': 'ok'})
                    except:
                        return  jsonify({'mess':'次要图片上传错误'})
            else:
                return jsonify({"errno": 1001, "errmsg": "上传失败"})
        except:
            return jsonify({"errno": 1001, "errmsg": "文件类型错误"})


    
    
@app.route('/del_goods',methods=['GET','POST'])
def del_goods():
    if request.method=="GET":
        return  render_template('del_goods.html')
    if request.method=='POST':
        request_data = json.loads(request.data.decode('utf-8'))
        goods_name=request_data['goods_name']
        goods = Goods(goods_name)
        if goods.del_sql()==0:
            return jsonify({'mess': 'error'})
        else:
            return jsonify({'mess': 'ok'})
            

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=8000,debug=True)




    

    
