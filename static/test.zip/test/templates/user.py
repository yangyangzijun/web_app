import pymysql
from flask import session


db = pymysql.connect(host='103.46.128.43', port=14704, user='root', passwd='', db='web_db', charset='utf8',
                         autocommit=1)



def op_sql(s):
    if s[0]=="s" :
        
        try:
            db = pymysql.connect(host='192.168.43.166', port=3307, user='root', passwd='', db='web_db', charset='utf8',
                            autocommit=1)
            cursor = db.cursor()
            print(s)
            cursor.execute(s)
            cursor.close()
            db.commit()
            return cursor.fetchall()
    
        except:
            pass
    else:
        try:
            db = pymysql.connect(host='192.168.43.68', port=3306, user='root', passwd='', db='web_db', charset='utf8',
                                 autocommit=1)
            cursor = db.cursor()
            print(s)
            cursor.execute(s)
            cursor.close()
            db.commit()
            return cursor.fetchall()
    
        except:
            pass
        
    
    
def cal_sub(s):
    print(s[0:-1])
    
    cursor = db.cursor()
    cursor.execute(f"select sum(price*num) from orders,goods where goods.goods_id = orders.goods_id and orders.order_id in ({s[0:-1]})")
    cursor.close()
    return cursor.fetchall()[0][0]
    



class Goods:
    id=None
    goods_name = None
    goods_nums = None
    price = None
    type = None
    photo = None
    def __init__(self,name = None,nums= 0,price = 99999,type = None,photo = None):
        self.goods_name=name
        self.id=None
        self.type=type
        self.goods_nums=int(nums)
        self.price=int(price)
        self.photo = photo
    def add_sql(self):
        try:
            cursor = db.cursor()
            cursor.execute(f"insert into goods values (NULL,'{self.goods_name}',{self.goods_nums},{self.price},'{self.type}','{ self.photo}')")
            db.commit()
            
            cursor.execute(f"select goods_id from goods where goods_name = '{self.goods_name}'")
            
            data=cursor.fetchall()
            cursor.close()
            return data[0][0]
        except:
            return 0


    def del_sql(self):
        try:
            cursor = db.cursor()
            cursor.execute(f"delete from goods where goods_name='{self.goods_name}'")
            db.commit()
            cursor.close()
            return 1
        except:
            return 0


   
        












            
        
    
            
        
        
