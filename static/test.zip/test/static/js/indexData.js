var recommendGoodsInfo = [
							{
								"src": "img/index/jingpintuijian01.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/jingpintuijian02.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/jingpintuijian03.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/jingpintuijian04.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/jingpintuijian05.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/jingpintuijian06.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/jingpintuijian07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/jingpintuijian08.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/jingpintuijian09.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/jingpintuijian10.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/jingpintuijian11.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/jingpintuijian12.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/jingpintuijian13.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/jingpintuijian14.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/jingpintuijian15.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							}];

var moreSmartWearInfo = [
							{
								"src": "img/index/moreSmartWear01.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/moreSmartWear02.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/moreSmartWear03.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreSmartWear04.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreSmartWear05.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreSmartWear06.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/moreSmartWear07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/moreSmartWear08.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/moreSmartWear09.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreSmartWear10.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreSmartWear11.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreSmartWear12.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/moreSmartWear13.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreSmartWear14.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							}];

var moreSmartHomeInfo = [
							{
								"src": "img/index/moreSmartHome01.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/moreSmartHome02.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/moreSmartHome03.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreSmartHome04.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreSmartHome05.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreSmartHome06.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/moreSmartHome07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/moreSmartHome08.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/moreSmartHome09.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreSmartHome10.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreSmartHome11.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreSmartHome12.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/moreSmartHome13.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreSmartHome14.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							}];

var hotItemGoodsInf = [
							{
								"src": "img/index/rexiaodanping01.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/rexiaodanping02.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/rexiaodanping03.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/rexiaodanping04.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/rexiaodanping05.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/rexiaodanping06.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/rexiaodanping07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/rexiaodanping08.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							}];

var mobilePhoneInf = [
							{
								"src": "img/index/mobilephone02.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/mobilephone03.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/mobilephone04.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/mobilephone05.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/mobilephone06.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/mobilephone07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/mobilephone08.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/mobilephone09.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/mobilephone10.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/mobilephone11.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/mobilephone12.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/mobilephone13.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/mobilephone14.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/mobilephone15.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/mobilephone16.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/mobilephone17.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/mobilephone18.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/mobilephone19.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/mobilephone20.jpg",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							}];

var personalComputerInf = [
							{
								"src": "img/index/personalComputer02.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/personalComputer03.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/personalComputer04.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/personalComputer05.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/personalComputer06.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/personalComputer07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/personalComputer08.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/personalComputer09.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/personalComputer10.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							}];

var wellTabletInf = [
							{
								"src": "img/index/wellTablet02.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/wellTablet03.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/wellTablet04.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/wellTablet05.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/wellTablet06.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/wellTablet07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/wellTablet08.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/wellTablet09.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/wellTablet10.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							}];

var smartWearInf = [
							{
								"src": "img/index/smartWear02.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/smartWear03.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/smartWear04.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/smartWear05.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/smartWear06.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/smartWear07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/smartWear08.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/smartWear09.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							}];

var smartHomeInf = [
							{
								"src": "img/index/smartHome02.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/smartHome03.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/smartHome04.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/smartHome05.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/smartHome06.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/smartHome07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/smartHome08.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/smartHome09.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							}];

var hotPartsInf = [
							{
								"src": "img/index/hotParts02.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/hotParts03.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/hotParts04.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/hotParts05.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/hotParts06.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/hotParts07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/hotParts08.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/hotParts09.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							}];

var moreHotPartsInfo = [
							{
								"src": "img/index/moreHotParts01.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/moreHotParts02.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/moreHotParts03.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreHotParts04.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreHotParts05.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreHotParts06.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/moreHotParts07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/moreHotParts08.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/moreHotParts09.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreHotParts10.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreHotParts11.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreHotParts12.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/moreHotParts13.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreHotParts14.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							}];

var brandPartsInf = [
							{
								"src": "img/index/brandParts02.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/brandParts03.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/brandParts04.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/brandParts05.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/brandParts06.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/brandParts07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/brandParts08.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/brandParts09.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							}];

var moreBrandPartsInfo = [
							{
								"src": "img/index/moreBrandParts01.png",
								"name": "华为安居智能摄像机",
								"describ":"订金10抵40",
								"price": "￥299"
							},
							{
								"src": "img/index/moreBrandParts02.png",
								"name": "荣耀10青春版",
								"describ":"送耳机 老用户再送数据线",
								"price": "￥1399"
							},
							{
								"src": "img/index/moreBrandParts03.png",
								"name": "HUAWEI MateBook D",
								"describ":"限时优惠1110",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreBrandParts04.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"爆款现货速发",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreBrandParts05.png",
								"name": "FreeBuds 2系列",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreBrandParts06.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/moreBrandParts07.png",
								"name": "HUAWEII Mate 20 Pro",
								"describ":"老用户享好礼",
								"price": "￥7779"
							},
							{
								"src": "img/index/moreBrandParts08.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/moreBrandParts09.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreBrandParts10.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreBrandParts11.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							},
							{
								"src": "img/index/moreBrandParts12.png",
								"name": "荣耀V10",
								"describ":"限时优惠1110",
								"price": "￥1779"
							},
							{
								"src": "img/index/moreBrandParts13.png",
								"name": "HUAWEII Mate 20 X",
								"describ":"新品震撼开售",
								"price": "￥4999"
							},
							{
								"src": "img/index/moreBrandParts14.png",
								"name": "荣耀畅玩8A",
								"describ":"新品震撼开售",
								"price": "￥779"
							}];

var noticInf = ['荣耀青春版 中奖名单公布',
				 '华为企业购 感恩回馈',
				 '荣耀年货节 全场最高900元'
				];





